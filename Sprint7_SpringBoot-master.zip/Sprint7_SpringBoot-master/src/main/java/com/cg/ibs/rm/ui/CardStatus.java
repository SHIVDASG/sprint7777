package com.cg.ibs.rm.ui;

public enum CardStatus {
		ACTIVE, BLOCKED, PENDING, INACTIVE
}
