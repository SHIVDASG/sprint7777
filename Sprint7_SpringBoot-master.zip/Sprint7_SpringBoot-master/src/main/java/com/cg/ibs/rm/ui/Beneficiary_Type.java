package com.cg.ibs.rm.ui;

public enum Beneficiary_Type {
	MY_ACCOUNT_IN_IBS, MY_ACCOUNT_IN_OTHER_BANKS, OTHERS_ACCOUNT_IN_IBS, OTHERS_ACCOUNT_IN_OTHER_BANKS
}

//creditcard expiry date
//exceptions not working
